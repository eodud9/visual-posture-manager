import { saveCalibration } from "../../../api/calibrations";
import { useEffect, useRef, useState } from "react";
import { PostureEngine } from "../../../utils/postureEngine";

export const usePoseDetection = (videoRef, status, calibrationPhase, setCalibrationPhase) => {
  const wsRef = useRef(null);
  const engineRef = useRef(null);
  const frameCountRef = useRef(0);

  // 추가
  const poseRef = useRef(null);
  const cameraRef = useRef(null);

  const [postureStatus, setPostureStatus] = useState("idle");
  const [calibProgress, setCalibProgress] = useState(0);
  const [postureScore, setPostureScore] = useState(null);
  const [isBadPosture, setIsBadPosture] = useState(false);

  const handlePostureResult = async (data) => {
    if (data.status === "CALIBRATING") {
      setPostureStatus("calibrating");
      setCalibProgress(data.progress);
    } else if (data.status === "CALIBRATED") {
      setCalibProgress(100);
      setPostureStatus("calibrated");

      try {
        await saveCalibration({
          sample_frame_count: data.sample_frame_count,
          feature_names: data.feature_names,
          feature_median: data.feature_median,
          covariance_matrix: data.covariance_matrix,
          threshold: data.threshold,
          alpha: data.alpha,
          landmarks_used: data.landmarks_used,
          ridge_applied: data.ridge_applied,
        });
      } catch (e) {
        console.error(e);
      }

      setCalibrationPhase("running");
    } else if (data.status === "MONITORING") {
      setPostureScore(data.score);
      setIsBadPosture(data.is_bad);
    }
  };

  const handlePostureResultRef = useRef(handlePostureResult);
  handlePostureResultRef.current = handlePostureResult;

  /*
   * websocket
   */
  useEffect(() => {
    if (calibrationPhase === "idle") {
      wsRef.current?.close();
      wsRef.current = null;

      setPostureStatus("idle");
      setCalibProgress(0);
      setPostureScore(null);
      setIsBadPosture(false);
      return;
    }

    const ws = new WebSocket("ws://localhost:8000/ws/posture");

    ws.onopen = () => console.log("ws connected");
    ws.onmessage = (e) => handlePostureResultRef.current(JSON.parse(e.data));

    ws.onerror = () => console.warn("[WS] fallback local engine");

    wsRef.current = ws;

    return () => ws.close();
  }, [calibrationPhase]);

  /*
   * mediapipe (1회만)
   */
  useEffect(() => {
    if (status !== "active") return;
    if (!window.Pose || !window.Camera) return;
    if (!videoRef.current) return;

    // 이미 생성됐으면 skip
    if (poseRef.current) return;

    const pose = new window.Pose({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
    });

    pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

    pose.onResults((results) => {
      if (!results.poseLandmarks) return;

      // idle이면 아예 무시
      if (calibrationPhase === "idle") return;

      frameCountRef.current++;

      if (frameCountRef.current % 3 !== 0) return;

      const landmarks = results.poseLandmarks.map(({ x, y, z }) => ({ x, y, z }));

      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ landmarks }));
      } else {
        if (!engineRef.current) {
          engineRef.current = new PostureEngine();
        }

        const result = engineRef.current.processFrame(landmarks);

        handlePostureResultRef.current(result);
      }
    });

    const camera = new window.Camera(videoRef.current, {
      onFrame: async () => {
        await pose.send({
          image: videoRef.current,
        });
      },
      width: 640,
      height: 480,
    });

    camera.start();

    poseRef.current = pose;
    cameraRef.current = camera;

    return () => {
      cameraRef.current?.stop();
      poseRef.current?.close();

      cameraRef.current = null;
      poseRef.current = null;
    };
  }, [status]); // <-- calibrationPhase 제거

  return {
    postureStatus,
    calibProgress,
    postureScore,
    isBadPosture,
  };
};
