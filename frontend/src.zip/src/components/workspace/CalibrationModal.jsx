import React, { useEffect, useRef, useState } from "react";

export const CalibrationModal = ({ open, stream, calibProgress, calibrationPhase, setCalibrationPhase, onClose }) => {
  const videoRef = useRef(null);
  const [videoReady, setVideoReady] = useState(false);

  useEffect(() => {
    const video = videoRef.current;

    if (!stream || !video) return;

    if (video.srcObject !== stream) {
      video.srcObject = stream;
    }

    video.onloadedmetadata = () => {
      video.play().catch(() => {});
    };
  }, [stream]);

  if (!open) return null;

  const handleStartCalibration = () => {
    if (!videoReady) return;

    setTimeout(() => {
      setCalibrationPhase("calibrating");
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-[999] bg-black/70 flex items-center justify-center">
      <div className="bg-white w-[50vw] max-w-3xl rounded-2xl p-6 shadow-xl">
        <h2 className="text-2xl font-bold mb-4 text-center">자세 캘리브레이션</h2>

        <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            onLoadedMetadata={() => setVideoReady(true)}
            className="w-full h-full object-cover"
          />

          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute left-1/2 top-[15%] -translate-x-1/2 w-[40%] h-[65%] border-4 border-dashed border-blue-400 rounded-[40%]" />
          </div>
        </div>

        <p className="text-center text-gray-500 mt-4">어깨와 머리가 가이드라인 안에 들어오도록 앉아주세요</p>

        {calibrationPhase === "calibrating" && (
          <>
            <div className="w-full h-3 bg-gray-200 rounded mt-6">
              <div className="bg-blue-600 h-3 rounded" style={{ width: `${calibProgress}%` }} />
            </div>

            <p className="text-center mt-2 text-sm">{calibProgress}%</p>
          </>
        )}

        <div className="flex justify-center gap-3 mt-6">
          {calibrationPhase === "idle" && (
            <button onClick={handleStartCalibration} className="bg-blue-600 text-white px-6 py-3 rounded-lg">
              캘리브레이션 시작
            </button>
          )}

          <button onClick={onClose} className="bg-gray-200 px-6 py-3 rounded-lg">
            취소
          </button>
        </div>
      </div>
    </div>
  );
};
