import React, { useEffect, useState } from "react";
import { WorkHeader } from "./workspace/WorkHeader";
import { WorkTimer } from "./workspace/WorkTimer";
import { WorkCam } from "./workspace/WorkCam";
import { CalibrationModal } from "./workspace/CalibrationModal";

const parseTime = (timeStr) => {
  const [m, s] = timeStr.split(":").map(Number);
  return m * 60 + s;
};

export const Workspace = () => {
  const [timeLeft, setTimeLeft] = useState(parseTime("00:05"));
  const [isRunning, setIsRunning] = useState(false);
  const [sessionId, setSessionId] = useState(null);

  const [calibrationPhase, setCalibrationPhase] = useState("idle");
  const [showCalibrationModal, setShowCalibrationModal] = useState(false);

  const [stream, setStream] = useState(null);

  // 추가
  const [calibProgress, setCalibProgress] = useState(0);

  useEffect(() => {
    let mediaStream;

    const init = async () => {
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });

        setStream(mediaStream);
      } catch (e) {
        console.error(e);
      }
    };

    init();

    return () => {
      mediaStream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const onStartRequest = () => {
    setShowCalibrationModal(true);
  };

  useEffect(() => {
    if (calibrationPhase === "running") {
      setShowCalibrationModal(false);
      setIsRunning(true);
    }
  }, [calibrationPhase]);

  return (
    <div className="p-4 flex flex-col gap-4">
      <WorkHeader />

      <WorkTimer
        timeLeft={timeLeft}
        setTimeLeft={setTimeLeft}
        isRunning={isRunning}
        setIsRunning={setIsRunning}
        sessionId={sessionId}
        setSessionId={setSessionId}
        calibrationPhase={calibrationPhase}
        setCalibrationPhase={setCalibrationPhase}
        onStartRequest={onStartRequest}
      />

      <WorkCam
        stream={stream}
        timeLeft={timeLeft}
        isRunning={isRunning}
        setIsRunning={setIsRunning}
        sessionId={sessionId}
        calibrationPhase={calibrationPhase}
        setCalibrationPhase={setCalibrationPhase}
        setCalibProgress={setCalibProgress}
      />

      <CalibrationModal
        open={showCalibrationModal}
        stream={stream}
        calibProgress={calibProgress}
        calibrationPhase={calibrationPhase}
        setCalibrationPhase={setCalibrationPhase}
        onClose={() => setShowCalibrationModal(false)}
      />
    </div>
  );
};
